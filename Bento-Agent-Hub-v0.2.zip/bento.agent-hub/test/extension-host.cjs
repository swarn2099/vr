const assert=require('node:assert/strict');
const vscode=require('vscode');
exports.run=async()=>{
 const extension=vscode.extensions.getExtension('bento-local.bento-agent-hub');
 assert.ok(extension,'Development extension registered');
 await extension.activate();
 assert.equal(extension.isActive,true);
 const commands=await vscode.commands.getCommands(true);
 for(const name of ['run','queue','watch','answer','resume','pause','details','refresh','doctor','copilot'])assert.ok(commands.includes(`bento.${name}`),`Command bento.${name} is registered`);
 await vscode.commands.executeCommand('bento.refresh');
 assert.ok(Array.isArray(await extension.exports.readStatus()),'Native backend loads inside Extension Host without a model runtime');
 assert.ok(vscode.lm.tools.some(t=>t.name==='bento_workflow'),'Native Copilot workflow tool registered');
 console.log('BENTO_EXTENSION_SMOKE_PASSED: activated, 10 commands registered, native workflow tool available, refresh succeeded');
};
