import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
for(const dir of ['src','test','scripts','extension'])for(const file of fs.readdirSync(dir))if(/\.(js|cjs)$/.test(file))execFileSync(process.execPath,['--check',path.join(dir,file)],{stdio:'inherit'});
console.log('JavaScript syntax checks passed.');
