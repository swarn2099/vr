# Native Copilot Chat edition — 0.2.0

This replaces version 0.1, which incorrectly required the Copilot SDK runtime.

On the work machine, preserve any needed `.bento` history and `config.local.json`, replace the old hub source with this version, run `npm ci`, install `extension/bento-agent-hub-0.2.0.vsix`, reload VS Code, and open `Bento.code-workspace`.

Enable Agent mode and the Bento workflow tool alongside your existing Jira/Figma/Chrome MCP tools. Run **Bento: Run Jira Story**. No Copilot CLI, SDK, model API key, Jira API credentials or duplicate MCP authentication is used.

The native Chat performs LLM work. CI monitoring runs while VS Code is open but repairs require resuming the Chat. No unattended background model is started. See README.md for setup and limits.

No dependencies, secrets, local configuration, or runtime data are included in this export.
