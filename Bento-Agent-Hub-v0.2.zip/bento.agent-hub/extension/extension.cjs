const vscode=require('vscode');
const fs=require('node:fs');
const path=require('node:path');
const {pathToFileURL}=require('node:url');
function activate(context){
 const changed=new vscode.EventEmitter();let monitoring=false,polling=false;
 function root(){
  const configured=vscode.workspace.getConfiguration('bento').get('hubPath');
  if(configured&&fs.existsSync(path.join(configured,'src/native.js')))return configured;
  const folder=vscode.workspace.workspaceFolders?.find(f=>fs.existsSync(path.join(f.uri.fsPath,'src/native.js'))&&fs.existsSync(path.join(f.uri.fsPath,'config.json')));
  if(!folder)throw new Error('Open the new Bento.code-workspace or set bento.hubPath to the updated hub folder.');
  return folder.uri.fsPath;
 }
 async function hub(){
  if(!vscode.workspace.isTrusted)throw new Error('Trust the workspace before using delivery tools.');
  const r=root();
  const bin=path.join(r,'node_modules','.bin');
  if(!(process.env.PATH||'').split(path.delimiter).includes(bin))process.env.PATH=bin+path.delimiter+(process.env.PATH||'');
  try {
   const [{config},{NativeHub}]=await Promise.all([import(pathToFileURL(path.join(r,'src/config.js')).href),import(pathToFileURL(path.join(r,'src/native.js')).href)]);
   return new NativeHub(config(r));
  }catch(e){throw new Error(`Could not load the hub. Run npm ci in ${r}. ${e.message}`);}
 }
 function stateDir(){const r=root(),base=JSON.parse(fs.readFileSync(path.join(r,'config.json'),'utf8')),local=path.join(r,'config.local.json');return path.resolve(r,(fs.existsSync(local)?JSON.parse(fs.readFileSync(local,'utf8')):{}).stateDir||base.stateDir);}
 function stories(){const d=stateDir();if(!fs.existsSync(d))return [];return fs.readdirSync(d).filter(f=>/^[A-Z][A-Z0-9_]*-\d+\.json$/.test(f)).map(f=>JSON.parse(fs.readFileSync(path.join(d,f),'utf8'))).sort((a,b)=>b.updatedAt.localeCompare(a.updatedAt));}
 async function keyOf(item){return item?.key||await vscode.window.showInputBox({prompt:'Jira story key',validateInput:v=>/^[A-Z][A-Z0-9_]*-[1-9][0-9]*$/.test(v)?undefined:'Enter a Jira key such as BBSMPLAT-1234'});}
 async function openChat(query){
  if(!vscode.workspace.isTrusted)throw new Error('Trust the workspace before starting delivery.');
  await vscode.commands.executeCommand('workbench.action.chat.open',{query});
 }
 const prefix='Use Copilot Agent mode with #bentoWorkflow and the existing Jira, Figma and Chrome DevTools MCP tools enabled in this VS Code Chat. Do not use Copilot CLI, Copilot SDK or an external LLM API. ';
 const provider={onDidChangeTreeData:changed.event,getChildren:()=>{try{return stories();}catch{return [];}},getTreeItem:s=>{
  const item=new vscode.TreeItem(s.key);item.description=`${s.status} · ${s.phase}`;item.tooltip=s.question||s.error||s.plan?.summary||s.key;item.contextValue=s.status;item.command={command:'bento.details',title:'View story',arguments:[s]};item.iconPath=new vscode.ThemeIcon(s.status==='ready'?'pass':s.status==='needs-input'?'question':s.status==='blocked'?'error':s.status==='awaiting-agent'?'comment-discussion':'sync');return item;
 }};
 context.subscriptions.push(vscode.window.registerTreeDataProvider('bento.stories',provider),changed);
 function register(name,fn){context.subscriptions.push(vscode.commands.registerCommand(`bento.${name}`,async(...args)=>{try{return await fn(...args);}catch(e){vscode.window.showErrorMessage(e.message);}}));}
 register('refresh',()=>changed.fire());
 for(const action of ['run','resume','copilot'])register(action,async item=>{const key=await keyOf(item);if(key)await openChat(prefix+`Deliver ${key}. Call bento_workflow action=advance, key=${key}. Perform each returned agentTask using your native tools, then submit action=complete with its stage/token/result. For missing information submit action=ask, show the question and stop. Continue until waiting for CI or human input, blocked or ready.`);});
 register('queue',()=>openChat(prefix+'Run my eligible Jira stories. Call bento_workflow action=queue for the JQL, search all pages with Jira MCP, enqueue the keys, then advance each requested story. Ask for a filter if none is configured.'));
 register('pause',async item=>{const key=await keyOf(item);if(key){await(await hub()).handle({action:'pause',key});vscode.window.showInformationMessage('Story paused. Stop its active Copilot turn as well to stop native file edits.');changed.fire();}});
 register('answer',async item=>{const key=await keyOf(item);if(!key)return;const h=await hub(),s=h.store.get(key);if(s?.status!=='needs-input')throw new Error('Story is not waiting for input.');const answer=await vscode.window.showInputBox({title:`${key}: ${s.question}`,prompt:'Your answer will be saved; use Resume Story to continue in Copilot Chat.',ignoreFocusOut:true});if(answer?.trim()){await h.handle({action:'answer',key,answer});changed.fire();}});
 register('details',async item=>{const key=await keyOf(item);if(!key)return;const s=stories().find(x=>x.key===key);if(!s)throw new Error('Story not found');const doc=await vscode.workspace.openTextDocument({language:'markdown',content:[`# ${s.key}`,`**${s.status}** · ${s.phase}`,s.plan?.summary||'',s.question||'',s.error||'',s.agentTask?.instruction||'',...Object.entries(s.prs).map(([repo,pr])=>`${repo}: ${pr.url}`),...s.history.slice(-25).map(e=>`${e.at} — ${e.message}`)].join('\n\n')});await vscode.window.showTextDocument(doc,{preview:true});});
 register('doctor',async()=>{
  const h=await hub(),names=vscode.lm.tools.map(t=>({name:t.name,description:t.description.slice(0,120)}));
  const report={mode:'Native Copilot Chat; no separate model login, CLI or API key',hub:h.c.root,workflowTool:names.some(t=>t.name==='bento_workflow'),mcpAndRelatedTools:names.filter(t=>/jira|atlassian|figma|chrome|devtools/i.test(t.name+' '+t.description)),jqlConfigured:!!h.c.jira.jql,notes:'Enable Agent mode and Bento workflow in Chat. MCP tools must be enabled in the SAME Chat. Local repository/CI checks: node src/cli.js doctor.'};
  const doc=await vscode.workspace.openTextDocument({language:'json',content:JSON.stringify(report,null,2)});await vscode.window.showTextDocument(doc,{preview:true});
 });
 register('watch',()=>{monitoring=!monitoring;vscode.window.showInformationMessage(monitoring?'CI monitoring started. Repairs will need Resume in Copilot Chat.':'CI monitoring stopped.');});
 let nextPoll=0;
 const timer=setInterval(async()=>{
  changed.fire();if(!monitoring||polling||Date.now()<nextPoll)return;polling=true;
  try{const h=await hub();nextPoll=Date.now()+h.c.pollSeconds*1000;const results=await h.pollCI();for(const s of results)if(s.status!=='waiting-ci')vscode.window.showInformationMessage(`${s.key}: ${s.status}${s.status==='awaiting-agent'?' — resume in Copilot Chat':''}`);}catch(e){nextPoll=Date.now()+120000;vscode.window.showErrorMessage(`Bento CI monitor: ${e.message}`);}finally{polling=false;}
 },2000);
 context.subscriptions.push({dispose:()=>clearInterval(timer)});
 context.subscriptions.push(vscode.lm.registerTool('bento_workflow',{
  async invoke(options,token){
   const h=await hub(),controller=new AbortController();
   const listener=token.onCancellationRequested(()=>controller.abort());
   if(token.isCancellationRequested)controller.abort();
   try {const result=await h.handle(options.input,{signal:controller.signal});changed.fire();return new vscode.LanguageModelToolResult([new vscode.LanguageModelTextPart(JSON.stringify(result))]);}
   finally{listener.dispose();}
  },
  prepareInvocation(options){return {invocationMessage:`Bento workflow: ${options.input.action}${options.input.key?' '+options.input.key:''}`};}
 }));
 return {readStatus:async()=> (await hub()).handle({action:'status'})};
}
module.exports={activate};
