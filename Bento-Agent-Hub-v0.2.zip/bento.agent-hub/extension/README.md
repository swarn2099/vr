# Bento Agent Hub 0.2

Native Copilot Chat delivery with persistent story tracking. No Copilot CLI, SDK or LLM API key.

Install dependencies with `npm ci` in the hub folder, open `Bento.code-workspace`, enable Agent mode and the **Bento delivery workflow** tool (`#bentoWorkflow`) alongside your existing Jira/Figma/Chrome MCP tools. Use **Bento: Run Jira Story**.

Copilot performs the model work in the native Chat. The extension persists stages and performs deterministic branch/check/PR operations. **Toggle CI Monitoring** watches PR checks while VS Code remains open; coding and CI repairs require an active/resumed Chat turn. It does not schedule or invoke a background model. No Jira API credentials or duplicate MCP configuration are needed.

Upgrade from 0.1: replace the old hub source, install `bento-agent-hub-0.2.0.vsix`, reload VS Code and open the new portable workspace. See the root README for CI/repository setup and current limitations. Notifications are deferred.
