# Bento Agent Hub 0.2 — native Copilot Chat

This version uses **only your existing Copilot Chat inside VS Code** for all LLM work. It does not use Copilot CLI, the Copilot SDK, an LLM API key, a separate model login or Jira REST. Jira, Figma and Chrome DevTools are used directly by the native agent through the MCP connections already enabled in the same Chat.

Version 0.1 used a separate Copilot SDK runtime. That was incompatible with a VS Code Chat-only entitlement. Replace the old hub files and install the new 0.2.0 extension; the old setup instructions no longer apply.

## Install on your work computer

1. Extract the supplied ZIP. Rename its folder to `bento.agent-hub` and place it beside `bento.webclient`, `bento.mobileapp`, and `bento.js-lib`.
2. In that folder run `npm ci` using Node.js 22+. This installs workflow/build dependencies, not a model runtime. Git and GitHub CLI are used for repository and PR operations, independently of your Copilot login. The repo's development toolchains and corporate registry/certificate access are still required.
3. In VS Code, use Extensions → … → Install from VSIX and choose `extension/bento-agent-hub-0.2.0.vsix`. Reload VS Code after upgrading.
4. Open `Bento.code-workspace`. It discovers the hub location from the opened folders; there are no personal-machine paths in the shipped workspace. If repositories are elsewhere, update the folder paths and `repos.<name>.path` in local configuration.
5. Sign into Copilot Chat normally. Open **Agent mode** (or select `bento-delivery`). In its tools picker enable **Bento delivery workflow** / `#bentoWorkflow` and your existing Jira, Figma and Chrome DevTools MCP tools. Keep MCP authentication in VS Code; no duplicate server definitions or tokens are needed in the hub.
6. Run **Bento: Check Setup** to inspect the native workflow/tool availability. It lists tools that appear relevant; it cannot prove that a remote MCP login is working. Test a read-only Jira lookup in Chat to establish that connection.
7. Create `config.local.json` from `config.local.example.json`. Replace placeholders: eligible-story JQL, required GitHub check names, CodeBuild region, and Bitrise app slug. A single story does not require JQL. Configure GitHub repository access and AWS/Bitrise credentials through your approved local authentication mechanism. These are CI/source-control credentials, not LLM credentials.
8. Confirm the shared library's base branch. The requested default remains `dev`, but the original checkout had only `origin/main`. The workflow asks if the requested base cannot be fetched; it does not silently target main.

Any old `jira.baseUrl`, `jira.mcpServer` or hub `mcpServers` settings are ignored in native mode and can be removed. Jira API tokens and a separate Copilot runtime login are not used.

## Run your first story

Choose **Bento: Run Jira Story** and enter a real Jira key. This opens Copilot Chat with a workflow prompt. If the current Chat is in Ask/Plan mode, switch to **Agent** and send the prompt.

You can also type directly in Copilot Agent Chat:

```text
Use #bentoWorkflow to deliver BBSMPLAT-1234. Read Jira through my existing Jira MCP. Follow the returned workflow stages and ask me when requirements are missing.
```

The native agent calls the extension's `bento_workflow` tool, which returns a saved stage, token and instructions. Copilot then performs that stage with its own editing, terminal and MCP tools, and submits the result. The extension handles branch/worktree creation, configured checks, pushes and PR creation. The native conversation shows the agent's actions; the Bento sidebar shows persistent ticket progress.

VS Code or your organization may require tool confirmations. This extension does not bypass those controls. No external model credentials are requested. If your organization disallows custom extension tools, the workflow cannot operate through this integration without that policy being changed.

When a question is saved, answer it in Chat or use **Bento: Answer Question**, then **Resume Story**. The same stage resumes with your saved context. Do not run the same ticket in two Chat sessions simultaneously; stage tokens prevent stale completion submissions, but cannot prevent two chats editing files at the same time.

## Queue and automation limits

**Bento: Run My Ready Stories** opens a native Chat prompt that reads the configured JQL, searches Jira through your MCP, saves the keys and advances the requested stories. Separate native Chat sessions can work on independent tickets; use dedicated browser/device contexts for UI checks.

**Bento: Toggle CI Monitoring** polls saved PRs while this VS Code window is open. It performs only deterministic CI operations; it never invokes an LLM. If CI fails, it retrieves configured logs and saves a repair task. Select **Resume Story** to continue that repair inside Copilot Chat.

There is **no unattended LLM worker, scheduled Jira pickup, or automatic wakeup of Copilot Chat** in this version. A coding/repair turn runs until Copilot finishes, reaches its limits, requests input, is cancelled or the window closes. You must resume as needed. Fully unattended delivery cannot be promised with only interactive Chat access.

**Pause Story** prevents workflow advancement. Also stop the active Copilot turn to stop its native file/terminal tools; the extension does not control those tools itself. Monitoring stops on window reload/close and can be toggled back on.

## Validation and PR behavior

- Branches start from the configured remote base in `.bento/worktrees/<KEY>/<repo>`. Original checkouts remain on their current branches.
- Intake must use actual Jira MCP results and resolve material ambiguities before coding.
- Copilot edits only the assigned worktrees. It reads existing repository instructions, adds focused tests and leaves changes uncommitted.
- The workflow runs each repository's configured checks. Test failures produce a native repair task, bounded by the configured retry limit.
- Native Copilot verifies actual worktree behavior. UI stories require Chrome DevTools or native device/simulator evidence; linked Figma designs must be checked through Figma. Missing tools/accounts result in a question, not a claimed pass.
- Verification evidence and a stable source fingerprint are required before the workflow commits, pushes and opens/reuses PRs. Obvious credential files/private keys are rejected from staged changes; this is not a full secret scanner.
- GitHub CI checks are matched to the pushed commit. Empty/missing/pending checks cannot count as success. Configure all required branded mobile builds where applicable.
- CodeBuild/CloudWatch use the AWS SDK's standard credential chain. Bitrise log retrieval uses the configured token environment variable. Build log commits must match the pushed commit; providers testing a different synthetic merge commit need additional integration before those logs can be consumed automatically.
- All coordinated PRs become ready only when required checks pass. The workflow does not merge, deploy, publish packages or send notifications.

Native tools run under your normal VS Code permissions. Worktrees isolate development changes, not OS privileges. Existing VS Code tool approvals and organizational policies still apply.

## Files and local commands

`config.json` holds defaults; `config.local.json` overrides them. Credential values belong in your approved secret/environment setup. Runtime state is in `.bento`, ignored by Git. Atomic saves and per-story locks protect state updates. `awaiting-agent` means an active native Chat needs to perform the returned task; it does not mean a background model is running.

Available local utilities:

```sh
node src/cli.js doctor
node src/cli.js status
node src/cli.js pause BBSMPLAT-1234
node src/cli.js answer BBSMPLAT-1234 "The user's actual answer"
```

Old `run`, `resume`, `auth`, `queue` and `watch` CLI commands explicitly reject standalone execution and direct you to VS Code. Do not try to fix them by adding a Copilot API key or installing Copilot CLI.

## Validation performed

`npm test` covers the deterministic runner and native handoff lifecycle, restart recovery, stale-token rejection, clarification/answers, pause, CI-to-native-repair handoff, local Git worktree isolation, check classification, source invalidation, cancellation and credential guards. An isolated VS Code Extension Host test checks activation, commands and registration of the native workflow tool. Tests do not establish that your work account's Jira MCP, organization policy or live end-to-end delivery succeeds; that still needs a real ticket run on your work machine.

Notifications remain deferred.

## References

- [VS Code extension tools in native Chat](https://code.visualstudio.com/api/extension-guides/ai/tools)
- [Custom agents in VS Code](https://code.visualstudio.com/docs/agent-customization/custom-agents)
