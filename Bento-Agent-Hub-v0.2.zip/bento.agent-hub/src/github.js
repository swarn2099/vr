import fs from 'node:fs';
import { createHash } from 'node:crypto';
import path from 'node:path';
import { CodeBuildClient, BatchGetBuildsCommand } from '@aws-sdk/client-codebuild';
import { CloudWatchLogsClient, GetLogEventsCommand } from '@aws-sdk/client-cloudwatch-logs';
import { command } from './process.js';
export async function gh(args,cwd) {const r=await command(['gh',...args],cwd);return r.output.trim();}
export async function api(route,cwd) {return JSON.parse(await gh(['api',route],cwd));}
export async function makeWorktree(c,s,name) {
  const r=c.repos[name],branch=`feature/${s.key.toLowerCase()}-agent`;
  await command(['git','fetch','origin',r.base],r.path);
  const dest=path.join(c.stateDir,'worktrees',s.key,name);
  if(fs.existsSync(dest)) {
    const current=(await command(['git','branch','--show-current'],dest)).output.trim();
    const actual=fs.realpathSync(path.resolve(dest,(await command(['git','rev-parse','--git-common-dir'],dest)).output.trim()));
    const expected=fs.realpathSync(path.resolve(r.path,(await command(['git','rev-parse','--git-common-dir'],r.path)).output.trim()));
    if(actual!==expected)throw new Error('Existing worktree belongs to a different repository');
    if(current!==branch) throw new Error(`Existing worktree at ${dest} is on unexpected branch ${current}`);
    return {path:dest,branch};
  }
  fs.mkdirSync(path.dirname(dest),{recursive:true});
  const existing=await command(['git','show-ref','--verify','--quiet',`refs/heads/${branch}`],r.path,{allowFailure:true});
  if(existing.code===0) throw new Error(`Branch ${branch} already exists outside this run; inspect before reusing`);
  await command(['git','worktree','add','-b',branch,dest,`origin/${r.base}`],r.path);
  return {path:dest,branch};
}
export function assertPublishable(files,diff) {
  const sensitive=files.filter(f=>/(^|\/)(?:\.env(?:\..*)?|\.npmrc|\.yarnrc|id_rsa|id_ed25519|.*\.(?:p12|pfx|key))$/.test(f) && !/\.(example|sample|template)$/.test(f));
  if(sensitive.length)throw new Error(`Sensitive/local configuration is staged: ${sensitive.join(', ')}. Keep credentials outside the PR.`);
  if(diff.split('\n').some(line=>line.startsWith('+') && /(?:gh[pousr]_[A-Za-z0-9_]{20,}|github_pat_[A-Za-z0-9_]{20,}|-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----)/.test(line)))throw new Error('A potential credential is present in the staged changes');
}
export async function fingerprint(c,s) {
  const h=createHash('sha256');
  for(const name of s.plan.repos) {
    const cwd=s.worktrees[name].path;h.update(name);
    h.update((await command(['git','rev-parse','HEAD'],cwd)).output);
    const tracked=(await command(['git','diff','HEAD','--name-only','-z'],cwd)).output.split('\0').filter(Boolean);
    const untracked=(await command(['git','ls-files','--others','--exclude-standard','-z'],cwd)).output.split('\0').filter(Boolean);
    for(const file of [...new Set([...tracked,...untracked])].sort()){h.update(file+'\0');const full=path.join(cwd,file);if(!fs.existsSync(full)){h.update('deleted');continue;}h.update(fs.lstatSync(full).isSymbolicLink()?fs.readlinkSync(full):fs.readFileSync(full));h.update('\0');}
  }
  return h.digest('hex');
}
export async function publish(c,s,name) {
  const r=c.repos[name],w=s.worktrees[name];
  const branch=(await command(['git','branch','--show-current'],w.path)).output.trim();
  if(branch!==w.branch) throw new Error('Worktree branch changed unexpectedly');
  const status=(await command(['git','status','--porcelain'],w.path)).output;
  if(status.trim()) {
    await command(['git','add','--all'],w.path);
    await command(['git','diff','--cached','--check'],w.path);
    const staged=(await command(['git','diff','--cached','--name-only','-z'],w.path)).output.split('\0').filter(Boolean);
    const diff=await command(['git','diff','--cached','--no-ext-diff','--unified=0'],w.path,{redactOutput:false});
    if(diff.truncated)throw new Error('Staged diff exceeds the automated review limit; split or review this change manually');
    assertPublishable(staged,diff.output);
    await command(['git','commit','-m',`${s.key}: ${s.plan.summary.slice(0,120)}`],w.path);
  }
  const ahead=(await command(['git','rev-list','--count',`origin/${r.base}..HEAD`],w.path)).output.trim();
  if(ahead==='0')throw new Error(`${name} has no changes to open a PR`);
  await command(['git','push','--set-upstream','origin',w.branch],w.path);
  const sha=(await command(['git','rev-parse','HEAD'],w.path)).output.trim();
  const prs=JSON.parse(await gh(['pr','list','--repo',r.github,'--head',w.branch,'--base',r.base,'--state','open','--json','number,url'],w.path));
  let pr=prs[0];
  if(!pr) {
    const body=path.join(c.stateDir,`${s.key}-${name}-pr.md`);
    fs.writeFileSync(body,`## ${s.key}\n\n${s.plan.summary}\n\n### Acceptance criteria\n${s.plan.acceptanceCriteria.map(x=>`- ${x}`).join('\n')}\n\n### Validation\n${(s.validation||[]).map(x=>`- ${x.repo}: ${x.command.join(' ')} — ${x.code===0?'passed':'failed'}`).join('\n')}\n\n${s.verification?.summary||''}\n${(s.verification?.evidence||[]).map(x=>`- ${x}`).join('\n')}\n\nCoordinated repositories: ${s.plan.repos.join(', ')}.\n`,{mode:0o600});
    await gh(['pr','create','--repo',r.github,'--base',r.base,'--head',w.branch,'--title',`${s.key}: ${s.plan.summary.slice(0,180)}`,'--body-file',body],w.path);
    pr=JSON.parse(await gh(['pr','view',w.branch,'--repo',r.github,'--json','number,url'],w.path));
  }
  return {...pr,sha};
}
export function classifyChecks(checks,statuses,required=[]) {
  const all=[...checks.map(x=>({name:x.name,state:x.status==='completed'?x.conclusion:'pending',url:x.details_url})),...statuses.map(x=>({name:x.context,state:x.state,url:x.target_url}))];
  const failed=all.filter(x=>['failure','error','timed_out','cancelled','action_required','startup_failure','stale'].includes(x.state));
  if(failed.length)return {state:'failed',checks:all,failed};
  const byName=new Map(all.map(x=>[x.name,x]));
  const missing=required.filter(n=>!byName.has(n));
  // Required skipped/neutral checks do not count as a pass. No checks is pending.
  const pending=all.some(x=>!['success','neutral','skipped'].includes(x.state)) || required.some(n=>byName.get(n)?.state!=='success');
  return {state:all.length && !missing.length && !pending?'passed':'pending',checks:all,missing};
}
export async function inspectCI(c,s,name) {
  const r=c.repos[name],pr=s.prs[name];
  const live=JSON.parse(await gh(['pr','view',String(pr.number),'--repo',r.github,'--json','headRefOid,state'],r.path));
  if(live.headRefOid!==pr.sha) throw new Error(`${name} PR head changed outside the runner; inspect before resuming`);
  if(live.state!=='OPEN')throw new Error(`${name} PR is ${live.state}; this run no longer owns an open PR`);
  const pages=async endpoint=>JSON.parse(await gh(['api','--paginate','--slurp',endpoint],r.path));
  const [checks,statusPages]=await Promise.all([pages(`repos/${r.github}/commits/${pr.sha}/check-runs?per_page=100`),pages(`repos/${r.github}/commits/${pr.sha}/statuses?per_page=100`)]);
  const latest=new Map();for(const status of statusPages.flat())if(!latest.has(status.context))latest.set(status.context,status);
  return classifyChecks(checks.flatMap(x=>x.check_runs),[...latest.values()],r.requiredChecks);
}
export async function failureLogs(c,s,name,ci) {
  const r=c.repos[name],out=[];
  for(const check of ci.failed||[]) {
    out.push(`${check.name}: ${check.state} ${check.url||''}`);
    if(!check.url)continue;
    const url=new URL(check.url);
    if(r.ci.provider==='codebuild' && (url.hostname==='console.aws.amazon.com' || url.hostname.endsWith('.console.aws.amazon.com'))) {
      const decoded=decodeURIComponent(check.url);
      const id=decoded.match(/(?:builds\/|buildId=)([A-Za-z0-9_-]+:[a-fA-F0-9-]+)/)?.[1];
      const region=r.ci.region||url.searchParams.get('region');
      if(!id || !region){out.push('CodeBuild build ID or AWS region unavailable; configure region and inspect the check URL.');continue;}
      const client=new CodeBuildClient({region});
      let build;
      try {build=(await client.send(new BatchGetBuildsCommand({ids:[id]}),{abortSignal:AbortSignal.timeout(30000)})).builds?.[0];}finally{client.destroy();}
      if(build?.resolvedSourceVersion && build.resolvedSourceVersion!==s.prs[name].sha)throw new Error('CodeBuild log commit does not match PR head');
      const logs=build?.logs;
      if(logs?.groupName && logs?.streamName){
        const cloudwatch=new CloudWatchLogsClient({region});
        try {const events=await cloudwatch.send(new GetLogEventsCommand({logGroupName:logs.groupName,logStreamName:logs.streamName,limit:1000,startFromHead:false}),{abortSignal:AbortSignal.timeout(30000)});out.push((events.events||[]).map(e=>e.message).join('\n'));}finally{cloudwatch.destroy();}
      }
    }
    if(r.ci.provider==='bitrise' && (url.hostname==='app.bitrise.io' || url.hostname==='www.bitrise.io')) {
      const slug=url.pathname.match(/\/build\/([a-zA-Z0-9]+)/)?.[1],app=r.ci.appSlug,token=process.env[r.ci.tokenEnv];
      if(!slug || !app || !token){out.push('Bitrise appSlug/token or build slug missing.');continue;}
      const buildResponse=await fetch(`https://api.bitrise.io/v0.1/apps/${encodeURIComponent(app)}/builds/${slug}`,{headers:{Authorization:token},signal:AbortSignal.timeout(30000),redirect:'error'});
      if(!buildResponse.ok)throw new Error(`Bitrise build HTTP ${buildResponse.status}`);
      const build=(await buildResponse.json()).data;
      if(build?.commit_hash!==s.prs[name].sha)throw new Error('Bitrise build commit does not match PR head');
      const response=await fetch(`https://api.bitrise.io/v0.1/apps/${encodeURIComponent(app)}/builds/${slug}/log`,{headers:{Authorization:token},signal:AbortSignal.timeout(30000),redirect:'error'});
      if(!response.ok)throw new Error(`Bitrise logs HTTP ${response.status}`);
      const data=await response.json();
      if(data.expiring_raw_log_url) {
        const raw=new URL(data.expiring_raw_log_url);
        if(raw.protocol!=='https:')throw new Error('Unexpected Bitrise log URL');
        const logs=await fetch(raw,{signal:AbortSignal.timeout(30000),redirect:'error'});
        if(!logs.ok)throw new Error(`Bitrise raw logs HTTP ${logs.status}`);
        out.push((await logs.text()).slice(-100000));
      } else if(data.log_chunks) out.push(JSON.stringify(data.log_chunks));
    }
  }
  return out.join('\n').slice(-120000);
}
