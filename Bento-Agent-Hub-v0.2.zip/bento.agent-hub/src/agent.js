// Model execution is owned exclusively by native Copilot Chat in VS Code.
import { randomUUID } from 'node:crypto';
export function validateResult(stage,result,c) {
  if(!result || typeof result.summary!=='string' || !result.summary.trim()) throw new Error('Agent omitted its summary');
  if(stage==='intake') {
    if(!Array.isArray(result.repos) || !result.repos.length || new Set(result.repos).size!==result.repos.length || result.repos.some(r=>!c.repos[r])) throw new Error('Agent must select known repositories without duplicates');
    if(!Array.isArray(result.acceptanceCriteria) || !result.acceptanceCriteria.length || result.acceptanceCriteria.some(x=>typeof x!=='string'||!x.trim())) throw new Error('Acceptance criteria are required');
    if(typeof result.uiRequired!=='boolean' || !Array.isArray(result.figmaUrls)) throw new Error('UI and design requirements must be explicit');
  }
  if(stage==='verify' && (result.verified!==true || !Array.isArray(result.evidence) || !result.evidence.length || result.evidence.some(x=>typeof x!=='string'||!x.trim()))) throw new Error('Verification requires evidence and verified=true');
  return result;
}

export function stageTask(c,s,stage) {
 const instructions={
  intake:`Use the Jira MCP already enabled in this Copilot Chat to read ${s.key}, ALL comments, acceptance criteria, links and relevant attachments. Investigate original repos read-only. Identify affected repositories, testable acceptance criteria, whether UI verification is needed and any Figma URLs. Never use Jira REST or invent unavailable Jira contents. Ask a specific question when requirements or access are insufficient.`,
  coding:'Read applicable AGENTS.md, .github/copilot-instructions.md and test guidance. Implement the story ONLY in the assigned worktrees. Use your normal Copilot editing, search and terminal tools. Install dependencies as needed. Add focused regression tests. For cross-repo changes, test clients against the worktree library without publishing it. Leave changes uncommitted.',
  repair:'Read the saved failure and logs, then fix the root cause ONLY in story worktrees. Do not weaken tests, skip checks or change CI policy to obtain a pass. Ask if the failure needs access, infrastructure or a product decision. Leave changes uncommitted.',
  verify:'Verify acceptance criteria against the actual worktree code. Use the current Chat Chrome DevTools MCP for browser UI, Figma MCP for linked designs, and configured native tooling for React Native. Record actual local source/branch, URL or device, scenarios and evidence. A remote dev/stage page alone does not validate local edits. Request clarification if required access/tooling is unavailable. Do not modify source during verification.'
 };
 return {stage,token:randomUUID(),instruction:instructions[stage],resultFields:stage==='intake'?['summary','repos','acceptanceCriteria','uiRequired','figmaUrls']:stage==='verify'?['summary','verified (true only after actual verification)','evidence']:['summary']};
}
export async function agent(c,s,stage) {return {handoff:stageTask(c,s,stage)};}
export async function discover() {throw new Error('Queue discovery runs inside Copilot Chat using your existing Jira MCP. Use Bento: Run My Ready Stories.');}
