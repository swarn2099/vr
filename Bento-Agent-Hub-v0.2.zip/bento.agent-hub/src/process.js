import { spawn } from 'node:child_process';
export function redact(text) {
  let s=String(text).replace(/(Bearer\s+|Basic\s+)[A-Za-z0-9._~+/=-]+/gi,'$1[REDACTED]').replace(/\b(?:gh[pousr]_[A-Za-z0-9_]+|github_pat_[A-Za-z0-9_]+)\b/g,'[REDACTED]');
  for(const [k,v] of Object.entries(process.env)) if (/(TOKEN|PASSWORD|SECRET|API_KEY)/i.test(k) && v && v.length>5) s=s.split(v).join('[REDACTED]');
  return s;
}
export async function command(argv, cwd, { timeout=120000, allowFailure=false, env={}, signal, redactOutput=true }={}) {
  if (!Array.isArray(argv) || !argv.length || !argv.every(x=>typeof x==='string')) throw new Error('Commands must be arrays of strings');
  return new Promise((resolve,reject)=>{
    const child=spawn(argv[0],argv.slice(1),{cwd,env:{...process.env,...env},stdio:['ignore','pipe','pipe'],detached:process.platform!=='win32'});
    let output='', timedOut=false, truncated=false, abortKill;
    const collect=data=>{output+=data.toString();if(output.length>2000000){truncated=true;output=output.slice(-2000000);}};
    child.stdout.on('data',collect); child.stderr.on('data',collect);
    const kill=()=>{ try { process.kill(-child.pid,'SIGTERM'); } catch { child.kill('SIGTERM'); } };
    const abort=()=>{kill();abortKill=setTimeout(()=>{try{process.kill(-child.pid,'SIGKILL');}catch{child.kill('SIGKILL');}},5000);};
    if(signal?.aborted) abort();
    signal?.addEventListener('abort',abort,{once:true});
    const timer=setTimeout(()=>{timedOut=true;kill();},timeout);
    const hard=setTimeout(()=>{try{process.kill(-child.pid,'SIGKILL');}catch{child.kill('SIGKILL');}},timeout+5000);
    child.on('error',e=>{clearTimeout(timer);clearTimeout(hard);clearTimeout(abortKill);signal?.removeEventListener('abort',abort);reject(e);});
    child.on('close',(code)=>{
      clearTimeout(timer);clearTimeout(hard);clearTimeout(abortKill);signal?.removeEventListener('abort',abort);
      if(signal?.aborted){reject(new Error('Command cancelled'));return;}
      const result={code:code??1,output:redactOutput?redact(output):output,timedOut,truncated};
      if (!allowFailure && (result.code!==0 || timedOut)) reject(new Error(`${argv[0]} failed${timedOut?' (timeout)':''}: ${redact(result.output.slice(-12000))}`)); else resolve(result);
    });
  });
}
