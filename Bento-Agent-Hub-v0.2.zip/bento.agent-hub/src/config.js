import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
export const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
export function merge(a, b) {
  const out = { ...a };
  for (const [k, v] of Object.entries(b)) out[k] = v && typeof v === 'object' && !Array.isArray(v) ? merge(a[k] || {}, v) : v;
  return out;
}
export function config(root = ROOT) {
  let c = JSON.parse(fs.readFileSync(path.join(root, 'config.json'), 'utf8'));
  const local = path.join(root, 'config.local.json');
  if (fs.existsSync(local)) c = merge(c, JSON.parse(fs.readFileSync(local, 'utf8')));
  c.root = root;
  c.stateDir = path.resolve(root, c.stateDir);
  for (const r of Object.values(c.repos)) r.path = path.resolve(root, r.path);
  for (const name of ['concurrency', 'pollSeconds', 'agentTimeoutMinutes', 'commandTimeoutMinutes']) {
    if (!Number.isInteger(c[name]) || c[name] < 1) throw new Error(`Invalid ${name}`);
  }
  if (!Number.isInteger(c.maxRepairAttempts) || c.maxRepairAttempts < 0) throw new Error('Invalid repair limit');
  return c;
}
export function expandEnv(value) {
  if (typeof value === 'string') return value.replace(/\$\{env:([A-Za-z_][A-Za-z0-9_]*)\}/g, (_, name) => {
    if (!process.env[name]) throw new Error(`Missing environment variable: ${name}`);
    return process.env[name];
  });
  if (Array.isArray(value)) return value.map(expandEnv);
  if (value && typeof value === 'object') return Object.fromEntries(Object.entries(value).map(([k,v]) => [k,expandEnv(v)]));
  return value;
}
