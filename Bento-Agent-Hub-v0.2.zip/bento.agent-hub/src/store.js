import fs from 'node:fs';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
export function ticketKey(key) {
  if (typeof key !== 'string' || !/^[A-Z][A-Z0-9_]*-[1-9][0-9]*$/.test(key)) throw new Error('Expected a Jira key such as BBSMPLAT-1234');
  return key;
}
export class Store {
  constructor(dir) { this.dir = dir; fs.mkdirSync(dir, { recursive: true, mode: 0o700 }); }
  file(key) { return path.join(this.dir, `${ticketKey(key)}.json`); }
  get(key) { const p = this.file(key); return fs.existsSync(p) ? JSON.parse(fs.readFileSync(p,'utf8')) : null; }
  list() { return fs.readdirSync(this.dir).filter(x => /^[A-Z][A-Z0-9_]*-\d+\.json$/.test(x)).map(x => this.get(x.slice(0,-5))).sort((a,b) => b.updatedAt.localeCompare(a.updatedAt)); }
  save(s) {
    s.updatedAt = new Date().toISOString();
    const dest = this.file(s.key), tmp = `${dest}.${randomUUID()}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(s,null,2)+'\n', { mode: 0o600 });
    fs.renameSync(tmp, dest); return s;
  }
  create(key, {locked=false}={}) {
    ticketKey(key);
    const existing=this.get(key);if(existing)return existing;
    const release=locked?()=>{}:this.lock(key);
    try {return this.get(key)||this.save({ key, phase:'intake', status:'queued', attempts:0, history:[], answers:[], worktrees:{}, prs:{} });}finally{release();}
  }
  event(s, message) { s.history.push({ at:new Date().toISOString(), phase:s.phase, message }); this.save(s); }
  lock(key) {
    const lock = path.join(this.dir, `${ticketKey(key)}.lock`);
    try { fs.writeFileSync(lock, String(process.pid), { flag:'wx', mode:0o600 }); }
    catch (e) {
      if (e.code !== 'EEXIST') throw e;
      const pid = Number(fs.readFileSync(lock,'utf8'));
      if (!Number.isInteger(pid) || pid < 1) throw new Error(`Invalid lock for ${key}; inspect before removing it`);
      try { process.kill(pid,0); } catch (err) {
        if (err.code !== 'ESRCH') throw err;
        fs.unlinkSync(lock); return this.lock(key);
      }
      throw new Error(`${key} is already running (process ${pid})`);
    }
    return () => fs.unlinkSync(lock);
  }
  answer(key, answer) {
    if (!answer?.trim()) throw new Error('An answer is required');
    const unlock=this.lock(key);
    try {
      const s=this.get(key);
      if (!s || s.status !== 'needs-input') throw new Error('This story is not waiting for input');
      s.answers.push({question:s.question,answer,at:new Date().toISOString()});
      delete s.question; s.status='queued'; this.event(s,'Clarification answered'); return s;
    } finally { unlock(); }
  }
  pause(key) { fs.writeFileSync(path.join(this.dir,`${ticketKey(key)}.pause`),'pause',{mode:0o600}); }
  unpause(key) { fs.rmSync(path.join(this.dir,`${ticketKey(key)}.pause`),{force:true}); }
  paused(key) { return fs.existsSync(path.join(this.dir,`${ticketKey(key)}.pause`)); }
}
