#!/usr/bin/env node
import path from 'node:path';
import { config } from './config.js';
import { NativeHub } from './native.js';
import { command } from './process.js';
const c=config();process.env.PATH=path.join(c.root,'node_modules','.bin')+path.delimiter+(process.env.PATH||'');
const hub=new NativeHub(c),[action,key,...rest]=process.argv.slice(2);
const output=x=>console.log(JSON.stringify(x,null,2));
try {
 switch(action){
  case 'doctor':{
   const checks=[{name:'Model access',mode:'Native Copilot Chat in VS Code only; no CLI/SDK/API key'}];
   for(const exe of ['git','gh','yarn']){try{await command([exe,'--version'],c.root);checks.push({name:exe,ok:true});}catch{checks.push({name:exe,ok:false});}}
   for(const [name,r]of Object.entries(c.repos)){
    const ref=await command(['git','show-ref','--verify',`refs/remotes/origin/${r.base}`],r.path,{allowFailure:true});checks.push({name:`${name}: origin/${r.base}`,ok:ref.code===0});
    const access=await command(['gh','api',`repos/${r.github}`,'--jq','.full_name'],r.path,{allowFailure:true});checks.push({name:`${name}: GitHub access`,ok:access.code===0});
    checks.push({name:`${name}: required CI checks`,ok:r.requiredChecks.length>0});
   }
   checks.push({name:'Jira JQL configured',ok:!!c.jira.jql});output(checks);break;
  }
  case 'status':output(await hub.handle({action:'status',key}));break;
  case 'pause':output(await hub.handle({action:'pause',key}));break;
  case 'answer':output(await hub.handle({action:'answer',key,answer:rest.join(' ')}));break;
  case 'enqueue':output(await hub.handle({action:'enqueue',keys:[key]}));break;
  case 'run':case 'resume':case 'queue':case 'watch':case 'auth':throw new Error('Use Bento commands in VS Code Copilot Chat. This version intentionally has no standalone model runner.');
  default:console.log('Bento Agent Hub 0.2 — native Copilot Chat\n\nUse VS Code: Bento: Run Jira Story.\nLocal utilities: doctor, status [KEY], enqueue KEY, pause KEY, answer KEY "answer".');
 }
}catch(e){console.error(e.message);process.exitCode=1;}
