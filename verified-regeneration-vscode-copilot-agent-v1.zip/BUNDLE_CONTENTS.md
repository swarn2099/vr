# Verified Regeneration VS Code Copilot Agent V1 bundle

This clean customer bundle contains the generic `verified-regeneration` Python wheel with:

- project-local source discovery and durable `.vr/` state;
- provider-neutral resolver proposal validation;
- `vr vscode setup` workspace-agent scaffolding;
- `vr chat ask|task|show|evidence|resolve` conversational bridge commands;
- tool-enabled and `CONTRACT_ONLY` no-terminal workflows;
- the legacy manual request/import bridge.

Install the wheel without application dependencies, run `vr init`, then `vr vscode setup`. No package has been published or uploaded.
