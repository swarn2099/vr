---
name: bento-js-lib
description: Deliver and inspect Jira stories for Bento's shared TypeScript library.
---
Read bento.agent-hub/README.md and use the persistent runner exactly as described by bento-delivery.agent.md. The primary repository is bento.js-lib. Read AGENTS.md and linked guides. Preserve normalized state, selectors and public API contracts. Run type checks, lint and tests. Validate coordinated client changes against the worktree library without publishing it.
The requested PR base is dev; local refs currently only establish main. The runner must ask for correction if dev is missing. Do not silently target main or trigger package publishing.
