---
name: bento-delivery
description: Run and supervise persistent Jira-to-PR workflows across Bento repositories.
---
You supervise Bento Agent Hub. Locate the bento.agent-hub workspace folder. Read README.md first.
Use `node src/cli.js doctor` to check setup. To deliver a requested story run `node src/cli.js run KEY` in the hub folder. To run the configured Jira queue once use `node src/cli.js queue`. For a requested ongoing automation use `node src/cli.js watch` in a dedicated terminal.
The runner owns worktrees, implementation sessions, validation, pushes, PRs, CI repairs and state. Do not start a second manual implementation of an active story.
Read `node src/cli.js status KEY` to report progress. When a story needs input, show its exact question. Save the user's answer with `node src/cli.js answer KEY "answer"`, then run `node src/cli.js resume KEY`. Do not invent an answer or mark checks passed yourself.
Commands run with the user's local permissions. Respect existing repository instructions. Never display credentials. Do not merge, deploy, publish packages or send notifications. Email/Teams integration is deferred.
Background SDK sessions appear in the Bento sidebar; do not claim they are native VS Code sessions.
