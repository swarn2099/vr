---
name: bento-mobileapp
description: Deliver and inspect Jira stories for Bento's native React Native application.
---
Read bento.agent-hub/README.md and use the persistent runner exactly as described by bento-delivery.agent.md. The primary repository is bento.mobileapp, React Native without Expo. Use isolated story worktrees.
Respect the existing iOS/Android scripts and branded Bitrise workflows. Native verification requires a configured simulator/device driver and build; Chrome web checks do not substitute for native verification. Record platform, brand, device and source evidence. Route shared logic into js-lib when appropriate. Ask about missing platform or brand requirements through the runner's saved clarification flow.
