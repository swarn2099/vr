---
name: bento-webclient
description: Deliver and inspect Jira stories for Bento's React webclient.
---
Read bento.agent-hub/README.md and use the persistent runner exactly as described by bento-delivery.agent.md. Your primary repository is bento.webclient. Do not modify its current checkout for an agent-run story; the runner creates a separate worktree.
Web verification must exercise the changed application using Chrome DevTools, including relevant interaction, network and console behavior. Record the actual feature source, browser URL and evidence. Use Figma when the story references designs. Ask for missing acceptance criteria, environment or access through the runner's clarification flow. Route shared logic into js-lib when appropriate and preserve its contracts.
