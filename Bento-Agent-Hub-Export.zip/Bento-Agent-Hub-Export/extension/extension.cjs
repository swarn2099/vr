const vscode=require('vscode');
const fs=require('node:fs');
const path=require('node:path');
const {spawn}=require('node:child_process');
function activate(context){
  const changed=new vscode.EventEmitter();
  function root(){
    const configured=vscode.workspace.getConfiguration('bento').get('hubPath');
    if(configured)return configured;
    const folder=vscode.workspace.workspaceFolders?.find(f=>fs.existsSync(path.join(f.uri.fsPath,'src/cli.js'))&&fs.existsSync(path.join(f.uri.fsPath,'config.json')));
    if(!folder)throw new Error('Open Bento.code-workspace or set bento.hubPath.');
    return folder.uri.fsPath;
  }
  function stateDir(){
    const r=root(),base=JSON.parse(fs.readFileSync(path.join(r,'config.json'),'utf8'));
    const local=path.join(r,'config.local.json');
    const override=fs.existsSync(local)?JSON.parse(fs.readFileSync(local,'utf8')):{};
    return path.resolve(r,override.stateDir||base.stateDir);
  }
  function stories(){
    const d=stateDir();if(!fs.existsSync(d))return [];
    return fs.readdirSync(d).filter(f=>/^[A-Z][A-Z0-9_]*-\d+\.json$/.test(f)).map(f=>JSON.parse(fs.readFileSync(path.join(d,f),'utf8'))).sort((a,b)=>b.updatedAt.localeCompare(a.updatedAt));
  }
  function launch(args){
    if(!vscode.workspace.isTrusted)throw new Error('Trust this workspace before running agents.');
    const node=vscode.workspace.getConfiguration('bento').get('nodePath','node');
    const terminal=vscode.window.createTerminal({name:`Bento: ${args.join(' ')}`,cwd:root(),shellPath:node,shellArgs:[path.join(root(),'src/cli.js'),...args]});
    terminal.show();return terminal;
  }
  async function keyOf(item){return item?.key||await vscode.window.showInputBox({prompt:'Jira story key',validateInput:v=>/^[A-Z][A-Z0-9_]*-[1-9][0-9]*$/.test(v)?undefined:'Enter a Jira key such as BBSMPLAT-1234'});}
  const provider={onDidChangeTreeData:changed.event,getChildren:()=>{try{return stories();}catch(e){vscode.window.showErrorMessage(e.message);return [];}},getTreeItem:s=>{
    const item=new vscode.TreeItem(s.key);item.description=`${s.status} · ${s.phase}`;item.tooltip=s.question||s.error||s.plan?.summary||s.key;
    item.contextValue=s.status;item.command={command:'bento.details',title:'View story',arguments:[s]};
    item.iconPath=new vscode.ThemeIcon(s.status==='ready'?'pass':s.status==='needs-input'?'question':s.status==='blocked'?'error':s.status==='paused'?'debug-pause':'sync');return item;
  }};
  context.subscriptions.push(vscode.window.registerTreeDataProvider('bento.stories',provider),changed);
  const timer=setInterval(()=>changed.fire(),2000);context.subscriptions.push({dispose:()=>clearInterval(timer)});
  function register(name,handler){context.subscriptions.push(vscode.commands.registerCommand(`bento.${name}`,async(...args)=>{try{await handler(...args);}catch(e){vscode.window.showErrorMessage(e.message);}}));}
  register('refresh',()=>changed.fire());
  for(const action of ['run','resume','pause'])register(action,async item=>{const key=await keyOf(item);if(key)launch([action,key]);});
  for(const action of ['queue','watch','doctor'])register(action,()=>launch([action]));
  register('answer',async item=>{
    const key=await keyOf(item);if(!key)return;
    const story=stories().find(s=>s.key===key);
    if(story?.status!=='needs-input')throw new Error('This story is not waiting for input.');
    const answer=await vscode.window.showInputBox({title:`${key}: ${story.question}`,prompt:'Your answer is saved locally; then use Resume Story.',ignoreFocusOut:true});
    if(answer?.trim())launch(['answer',key,answer]);
  });
  register('details',async item=>{
    const key=await keyOf(item);if(!key)return;
    const story=stories().find(s=>s.key===key);if(!story)throw new Error('Story not found');
    const lines=[`# ${story.key}`,story.plan?.summary||'',`**${story.status}** · ${story.phase}`,story.question?`## Needs your input\n\n${story.question}`:'',story.error||'',...Object.entries(story.prs).map(([repo,pr])=>`- ${repo}: ${pr.url}`),'## Recent activity',...story.history.slice(-30).map(e=>`${e.at} — ${e.message}`)];
    const doc=await vscode.workspace.openTextDocument({content:lines.join('\n\n'),language:'markdown'});await vscode.window.showTextDocument(doc,{preview:true});
  });
  register('copilot',async()=>{
    if(!vscode.workspace.isTrusted)throw new Error('Trust this workspace before starting an agent.');
    const key=await keyOf();if(!key)return;
    // VS Code's documented CLI supports named custom agents; no private Chat API.
    const child=spawn('code',['chat','--mode','bento-delivery',`Run Jira story ${key} using Bento Agent Hub. Read its custom agent instructions first.`],{cwd:root(),stdio:'ignore'});
    child.on('error',e=>vscode.window.showErrorMessage(`Could not open Copilot: ${e.message}`));
  });
}
module.exports={activate};
