# Bento Agent Hub

Open the generated `Bento.code-workspace`. The Bento sidebar shows saved story progress, questions and PRs.

Commands: **Bento: Run Jira Story**, **Run My Ready Stories**, **Start Automation**, **Check Setup**, **Open Delivery Agent in Copilot**.

Run commands start the persistent runner in a named terminal. Closing that terminal stops that process. The state remains on disk. Use Resume Story after a restart. Start Automation polls Jira and CI; stop it with Ctrl+C in its terminal. Notifications are intentionally deferred.

Set `bento.hubPath` to the hub directory and `bento.nodePath` to Node.js 22+ if not using the generated workspace. The runner and its dependencies must be installed separately (`npm ci` in the hub directory).

Copilot custom agents are available from the workspace's `.github/agents`. Background SDK sessions appear in the Bento sidebar, not automatically in VS Code's native agent session list.
