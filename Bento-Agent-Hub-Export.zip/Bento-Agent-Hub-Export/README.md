# Bento Agent Hub

A local delivery runner and VS Code extension for `bento.webclient`, `bento.mobileapp` and `bento.js-lib`. Run a Jira story, answer questions when needed, and follow it through isolated implementation, validation, a PR and CI repair. Teams/email notifications are deferred.

## Open it

Open **Bento.code-workspace** in VS Code. Install the local extension from `extension/bento-agent-hub-0.1.0.vsix` if not already installed. The Bento sidebar lists stories. Use **Bento: Check Setup**, then **Bento: Run Jira Story**. Four custom agents are in `.github/agents`: `bento-delivery`, `bento-webclient`, `bento-mobileapp`, and `bento-js-lib`.

The custom agents are entry points in Copilot Chat. They invoke the same persistent runner as the extension. Coding sessions run through the GitHub Copilot SDK and appear in the Bento sidebar; this implementation does **not** inject those SDK sessions into VS Code's native Agents session list. The extension uses VS Code's documented `code chat --mode` command to open the native custom-agent entry point.

## First-time setup

1. Install Node.js 22+, Git, GitHub CLI and this project's dependencies with `npm ci`.
2. The hub includes Yarn Classic 1.22.22 and makes it available to its runner sessions. Ensure the repository's required Node/native toolchain is available. Repo scripts, dependency install, corporate registry/certificate access, Xcode/Android SDK and mobile provisioning still apply. Node used by the runner and Node used by a repository may differ.
3. Authenticate GitHub CLI with an account authorized for `BentoInc`. An authenticated personal account alone does not establish repository access. `node src/cli.js auth` checks Copilot runtime authentication; Copilot entitlement/quota is required separately.
4. Create `config.local.json` using `config.local.example.json`. Replace every placeholder, and choose an explicit Jira JQL filter. Nothing polls your entire Jira account by default. This file and all runtime state are ignored by Git.
5. Configure Jira REST access **or** the Jira MCP server. REST supports Jira Cloud v3 and Data Center v2 with basic or bearer authentication. Set the named environment variables in the process that launches the runner. Do not put credentials into the example configuration or repository files.
6. Add your existing Figma, Chrome DevTools and Jira MCP definitions to `mcpServers` using `mcp.example.json` as a shape example. Use your real server URLs and credentials. `${env:NAME}` resolves from the runner environment and fails if absent. SDK authentication is independent of VS Code's stored OAuth/input credentials; copying a `${input:...}` reference will not transfer that login. No MCP definitions were imported automatically.
7. Set each repository's exact `requiredChecks` names, CodeBuild AWS region and Bitrise app slug/token environment variable. The AWS SDK uses your standard AWS credentials/profile (including supported SSO profiles) and needs read access to CodeBuild and CloudWatch logs; the AWS CLI is not required by the runner. GitHub PR checks must report the external build status on the pushed commit. Bitrise checks for multiple brands must all be listed when required.
8. Confirm the shared library PR base. The requested default is `dev`; this checkout has `origin/main` but no `origin/dev`. The runner stops rather than silently changing the target. Override `repos.js-lib.base` only after choosing the intended target.
9. Configure a dedicated browser context and dev/stage test account through your existing authentication mechanism. For native UI validation, provide a simulator/device MCP driver or usable repository test tooling. Without that, UI stories stop for clarification rather than falsely passing.

`config.local.json` is recursively merged over `config.json`; command arrays are replaced as a whole. `repos.<name>.checks` are argument arrays executed without a shell. Add native build checks for the platform/brand you use. The web start script defaults to the existing US Bank/dev script as a candidate; the agent must confirm the story's brand and actual local URL.

## Commands

Run in the hub directory:

```sh
node src/cli.js doctor
node src/cli.js run BBSMPLAT-1234
node src/cli.js status
node src/cli.js answer BBSMPLAT-1234 "Use the disabled state for cancelled cards."
node src/cli.js resume BBSMPLAT-1234
node src/cli.js pause BBSMPLAT-1234
node src/cli.js queue
node src/cli.js watch
```

`run` works through a story until it needs input, is blocked, becomes ready for review, or reaches pending CI. Use `watch --existing-only` to continue CI monitoring without picking up new Jira stories. `watch` discovers eligible stories and monitors saved runs every 120 seconds by default, with two concurrent stories. It reloads configuration between polling cycles. Stop it with Ctrl+C. It runs while its process and host remain running; it is not an installed system service and cannot work while the laptop is asleep. A dedicated always-on host can run the same command.

`pause` interrupts an active model session or validation command and persists the pause. Git operations already in flight complete before the next safe boundary. `answer` saves a response; `resume` continues immediately, or a running watcher picks it up on its next cycle. `blocked` means an operational failure: fix access/setup and resume explicitly. Questions and answers survive restarts. A rerun of a ready story does not open another PR.

## What the runner does

- Fetches Jira descriptions, links, attachment metadata and all comments via REST, or delegates read-only intake to your Jira MCP. Agents retrieve linked detail/designs as needed through configured tools.
- Investigates the story and repositories, saves acceptance criteria and repository routing, and asks about material ambiguities before implementation.
- Creates `feature/<jira-key>-agent` branches from the configured remote base in `.bento/worktrees/<KEY>/<repo>`. Original checkouts stay on their existing branches.
- Runs Copilot implementation, then the configured local checks. Validation output is saved locally with common credential patterns redacted.
- Runs a separate verification stage. UI/design verification must include concrete evidence. It serializes verification across stories because browser/device tools may share a session. Changes during verification invalidate previous local checks.
- Commits and pushes the story branch and opens/reuses a GitHub PR against its configured base. It checks for common credential files/private keys in staged changes. This is a guard against obvious mistakes, not a complete secret scanner.
- Reads GitHub checks/statuses for the exact pushed commit. No checks, pending checks, missing required checks and skipped required checks cannot count as a successful build. A PR modified externally stops the run for inspection.
- Retrieves failed CodeBuild/CloudWatch or Bitrise logs when configured, then re-enters implementation and validation, up to three repair attempts shared across local and CI failures.
- Marks all coordinated PRs ready for review only after required checks pass. Does not merge or publish packages. Cross-repo dependency changes must be tested against the worktree library; unresolved package-release ordering becomes a clarification question.

The model has ordinary local shell access for coding and tooling. Worktree isolation prevents checkout collisions; it is **not an OS security sandbox**. The permission handler constrains direct file-write tools to story worktrees, but cannot sandbox arbitrary shell commands. Use a dedicated account/host for stronger isolation. Keep credentials in your existing environment/secret store and avoid production test accounts.

## Files and recovery

Each `.bento/<KEY>.json` contains the current phase, plan, questions/answers, worktrees, checks, PR commit IDs and activity. Writes use temporary files followed by atomic rename. Per-story process locks prevent concurrent edits. Dead process locks are reclaimed; a live lock is never stolen. On a restarted run, the saved stage is retried; model context is reconstructed from the saved story instead of assuming an old model session is still alive. PR creation is recovered by looking up the existing branch PR. Keep `.bento` backed up if you need durable history across machine loss.

The automation queue is intentionally local to one host. Multi-host scheduling, a hosted webhook receiver, team-wide access control, notifications and two-way Teams/email replies are not implemented.

## Verification

```sh
npm test
npm run check
npm run package:extension
```

The VS Code extension also passed an isolated Extension Host smoke test: activation, all ten command registrations and refresh.

Tests exercise state persistence, lock contention, clarification/resume, CI repair and retry budgets, pending checks, source-change invalidation, credential guards, command timeouts and real Git worktree isolation against a temporary local remote. CI and agent workflow tests use test doubles: they do not claim a live Bento story was delivered.

The installed Copilot SDK runtime starts and authenticates with the current GitHub CLI account. The attempted live model/tool test was rejected with **monthly quota exceeded**. Jira access, Bento GitHub authorization, external CI credentials and UI MCP configuration still need to be connected before the first live end-to-end run.

## Integration references

- [VS Code custom agents](https://code.visualstudio.com/docs/agent-customization/custom-agents)
- [VS Code CLI / chat](https://code.visualstudio.com/docs/configure/command-line)
- [GitHub Copilot SDK](https://github.com/github/copilot-sdk) and [MCP configuration](https://docs.github.com/en/copilot/how-tos/copilot-sdk/features/mcp)
- [Jira issue search](https://developer.atlassian.com/cloud/jira/platform/rest/v3/api-group-issue-search/)
- [GitHub commit statuses](https://docs.github.com/en/rest/commits/statuses)
- [CodeBuild build details](https://docs.aws.amazon.com/codebuild/latest/APIReference/API_BatchGetBuilds.html)
- [Bitrise API](https://api-docs.bitrise.io/)
