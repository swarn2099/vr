import fs from 'node:fs';
import path from 'node:path';
import { Store } from './store.js';
import { agent, discover } from './agent.js';
import { issue, queue } from './jira.js';
import { command, redact } from './process.js';
import { makeWorktree, publish, inspectCI, failureLogs, fingerprint } from './github.js';
export const defaultServices={agent,issue,queue,discover,command,makeWorktree,publish,inspectCI,failureLogs,fingerprint};
export class Runner {
  constructor(c,services={}){this.c=c;this.store=new Store(c.stateDir);this.services={...defaultServices,...services};}
  wait(s,question){s.status='needs-input';s.question=redact(question);this.store.event(s,'Waiting for your input');return s;}
  async run(key,{resume=false}={}) {
    const unlock=this.store.lock(key),c=this.c,svc=this.services;
    let s=this.store.get(key)||this.store.create(key,{locked:true});
    const controller=new AbortController();
    const interrupt=()=>{this.store.pause(key);controller.abort();};
    process.once('SIGINT',interrupt);process.once('SIGTERM',interrupt);
    const timer=setInterval(()=>{if(this.store.paused(key))controller.abort();},500);
    const onEvent=message=>this.store.event(s,redact(message));
    try {
      if(s.status==='ready' || s.status==='needs-input')return s;
      if(s.status==='blocked' && !resume)return s;
      if(this.store.paused(key)){s.status='paused';this.store.save(s);return s;}
      s.status='running';delete s.error;this.store.save(s);
      for(let steps=0;steps<40;steps++) {
        if(controller.signal.aborted){s.status='paused';this.store.save(s);return s;}
        switch(s.phase) {
          case 'intake': {
            if(!s.issue && c.jira.baseUrl)s.issue=await svc.issue(c,s.key);
            if(!s.issue && !c.jira.mcpServer)return this.wait(s,'Configure Jira REST access or jira.mcpServer in config.local.json, then answer “configured”.');
            const outcome=await svc.agent(c,s,'intake',{onEvent,signal:controller.signal});
            if(outcome.question)return this.wait(s,outcome.question);
            s.plan=outcome.result;s.phase='worktrees';break;
          }
          case 'worktrees': {
            for(const name of s.plan.repos)if(!s.worktrees[name]) {
              try{s.worktrees[name]=await svc.makeWorktree(c,s,name);this.store.save(s);}
              catch(e){return this.wait(s,`Cannot prepare ${name} from ${c.repos[name].base}: ${e.message}\nCorrect the base branch or repository access in config.local.json, then answer to resume.`);}
            }
            s.phase='coding';break;
          }
          case 'coding': case 'repair': {
            const outcome=await svc.agent(c,s,s.phase,{onEvent,signal:controller.signal});
            if(outcome.question)return this.wait(s,outcome.question);
            s.implementation=outcome.result;s.phase='validation';break;
          }
          case 'validation': {
            s.validation=[];
            for(const name of s.plan.repos)for(const argv of c.repos[name].checks) {
              if(controller.signal.aborted)throw new Error('Story paused');
              const result=await svc.command(argv,s.worktrees[name].path,{allowFailure:true,timeout:c.commandTimeoutMinutes*60000,env:{CI:'true'},signal:controller.signal});
              const log=path.join(c.stateDir,`${s.key}-${name}-check-${s.validation.length}.log`);
              fs.writeFileSync(log,redact(result.output),{mode:0o600});
              s.validation.push({repo:name,command:argv,code:result.code,timedOut:result.timedOut,log});this.store.save(s);
            }
            const failed=s.validation.filter(x=>x.code!==0||x.timedOut);
            if(failed.length) {
              s.failure=failed.map(x=>`${x.repo}: ${x.command.join(' ')}\n${fs.readFileSync(x.log,'utf8').slice(-20000)}`).join('\n');
              if(s.attempts>=c.maxRepairAttempts)return this.wait(s,`Repair limit (${c.maxRepairAttempts}) reached. Inspect validation logs, fix the underlying setup or adjust maxRepairAttempts, then answer to retry.`);
              s.attempts++;s.phase='repair';
            } else {s.validatedFingerprint=await svc.fingerprint(c,s);s.phase='verify';}
            break;
          }
          case 'verify': {
            // Browser/device sessions can be shared MCP resources. Serialize verification.
            let release;
            try {release=this.store.lock('VERIFY-1');} catch {s.status='queued';this.store.save(s);return s;}
            let outcome;
            try {outcome=await svc.agent(c,s,'verify',{onEvent,signal:controller.signal});} finally {release();}
            if(outcome.question)return this.wait(s,outcome.question);
            if(await svc.fingerprint(c,s)!==s.validatedFingerprint){s.phase='validation';break;}
            s.verification=outcome.result;s.phase='publish';break;
          }
          case 'publish': {
            if(await svc.fingerprint(c,s)!==s.validatedFingerprint){s.phase='validation';break;}
            for(const name of s.plan.repos){s.prs[name]=await svc.publish(c,s,name);this.store.save(s);}
            s.phase='ci';break;
          }
          case 'ci': {
            const unspecified=s.plan.repos.filter(name=>!c.repos[name].requiredChecks.length);
            if(unspecified.length)return this.wait(s,`Set repos.<name>.requiredChecks to the exact GitHub CI check names for ${unspecified.join(', ')} in config.local.json. This prevents a partial set of checks from being mistaken for a green build. Answer after configuring.`);
            s.ci={};
            for(const name of s.plan.repos)s.ci[name]=await svc.inspectCI(c,s,name);
            const failed=Object.entries(s.ci).filter(([,v])=>v.state==='failed');
            if(failed.length){
              if(s.attempts>=c.maxRepairAttempts)return this.wait(s,`CI repair limit (${c.maxRepairAttempts}) reached. Inspect the PR/check logs; answer after fixing access or increasing the limit.`);
              const logs=[];for(const [name,ci]of failed)logs.push(`${name}\n${await svc.failureLogs(c,s,name,ci)}`);
              s.failure=redact(logs.join('\n'));s.attempts++;s.phase='repair';
            }else if(Object.values(s.ci).every(x=>x.state==='passed')){s.status='ready';this.store.event(s,'All required checks passed; PRs ready for review');return s;}
            else {s.status='waiting-ci';this.store.event(s,'Waiting for checks on the pushed commit');return s;}
            break;
          }
          default:throw new Error(`Unknown phase ${s.phase}`);
        }
        this.store.event(s,`Next: ${s.phase}`);
      }
      throw new Error('Workflow step limit reached');
    } catch(e) {
      s.status=controller.signal.aborted?'paused':'blocked';s.error=redact(e.message);this.store.event(s,s.error);return s;
    } finally {clearInterval(timer);process.removeListener('SIGINT',interrupt);process.removeListener('SIGTERM',interrupt);unlock();}
  }
  async tick({intake=true}={}) {
    let discoveryError;
    if(intake)try {
      const keys=await (this.c.jira.baseUrl?this.services.queue(this.c):this.services.discover(this.c));
      for(const key of new Set(keys))this.store.create(key);
    }catch(e){discoveryError=redact(e.message);}
    const eligible=this.store.list().filter(s=>['queued','waiting-ci','running'].includes(s.status)&&!this.store.paused(s.key));
    let index=0;const results=[];
    await Promise.all(Array.from({length:Math.min(this.c.concurrency,eligible.length)},async()=>{
      while(index<eligible.length){const s=eligible[index++];try{results.push(await this.run(s.key));}catch(e){results.push({key:s.key,error:e.message});}}
    }));
    return {discoveryError,results};
  }
}
