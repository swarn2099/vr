#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import { config } from './config.js';
import { Runner } from './runner.js';
import { command } from './process.js';
import { CopilotClient } from '@github/copilot-sdk';
const c=config();
process.env.PATH=path.join(c.root,'node_modules','.bin')+path.delimiter+(process.env.PATH||'');
const runner=new Runner(c),[action,key,...rest]=process.argv.slice(2);
const output=x=>console.log(JSON.stringify(x,null,2));
async function doctor() {
  const checks=[];
  for(const executable of ['git','gh','yarn']){
    try {await command([executable,'--version'],c.root);checks.push({name:executable,ok:true});}catch{checks.push({name:executable,ok:false});}
  }
  for(const [name,r]of Object.entries(c.repos)){
    const ref=await command(['git','show-ref','--verify',`refs/remotes/origin/${r.base}`],r.path,{allowFailure:true});
    checks.push({name:`${name}: origin/${r.base}`,ok:ref.code===0});
    checks.push({name:`${name}: required CI checks configured`,ok:r.requiredChecks.length>0});
    const access=await command(['gh','api',`repos/${r.github}`,'--jq','.full_name'],r.path,{allowFailure:true});
    checks.push({name:`${name}: GitHub API access`,ok:access.code===0});
  }
  try{await command(['gh','auth','status'],c.root);checks.push({name:'GitHub authentication',ok:true});}catch{checks.push({name:'GitHub authentication',ok:false});}
  checks.push({name:'Jira intake configured',ok:!!(c.jira.baseUrl||c.jira.mcpServer)});
  checks.push({name:'Jira queue filter configured',ok:!!c.jira.jql});
  checks.push({name:'MCP servers configured',servers:Object.keys(c.mcpServers)});
  output(checks);
}
try {
  switch(action){
    case 'doctor':await doctor();break;
    case 'auth': {
      const client=new CopilotClient({workingDirectory:c.root});
      try{await client.start();output(await client.getAuthStatus());}finally{await client.stop();}break;
    }
    case 'run':output(await runner.run(key,{resume:true}));break;
    case 'resume':runner.store.unpause(key);output(await runner.run(key,{resume:true}));break;
    case 'pause':runner.store.pause(key);output({key,status:'pause requested'});break;
    case 'answer':output(runner.store.answer(key,rest.join(' ')));break;
    case 'status':output(key?runner.store.get(key):runner.store.list());break;
    case 'queue':output(await runner.tick());break;
    case 'watch': {
      const unlock=runner.store.lock('WATCH-1');
      let stop=false;process.on('SIGINT',()=>{stop=true;});process.on('SIGTERM',()=>{stop=true;});
      try{while(!stop){const updated=config();if(updated.stateDir!==c.stateDir)throw new Error('Restart automation after changing stateDir');runner.c=updated;output(await runner.tick({intake:key!=='--existing-only'}));for(let n=0;n<c.pollSeconds&&!stop;n++)await new Promise(r=>setTimeout(r,1000));}}finally{unlock();}break;
    }
    case 'enqueue':output(runner.store.create(key));break;
    default: console.log(`Bento Agent Hub\n\n  doctor                 Check local setup\n  auth                   Check Copilot SDK authentication\n  run KEY                Run one Jira story through PR checks\n  queue                  Discover and run eligible Jira stories once\n  watch                  Poll Jira and CI until stopped\n  watch --existing-only  Monitor saved stories without new intake\n  status [KEY]           Show saved progress\n  answer KEY "answer"    Save clarification answer\n  resume KEY             Resume a paused/blocked/answered story\n  pause KEY              Stop agent work and pause at a safe boundary\n  enqueue KEY            Save a story without starting it\n\nSettings: ${path.join(c.root,'config.local.json')}`);
  }
} catch(e){console.error(e.message);process.exitCode=1;}
