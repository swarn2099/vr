import { ticketKey } from './store.js';
export async function jira(c, route, params={}) {
  if (!c.jira.baseUrl) throw new Error('Configure jira.baseUrl or a Jira MCP server');
  const token=process.env[c.jira.tokenEnv];
  if (!token) throw new Error(`Set ${c.jira.tokenEnv}`);
  const origin=new URL(c.jira.baseUrl);
  if(origin.protocol!=='https:') throw new Error('Jira URL must use HTTPS');
  const url=new URL(`${origin.pathname.replace(/\/$/,'')}/rest/api/${c.jira.apiVersion}/${route}`,origin);
  for(const [k,v] of Object.entries(params)) url.searchParams.set(k,String(v));
  const email=process.env[c.jira.emailEnv];
  if(c.jira.auth==='basic' && !email) throw new Error(`Set ${c.jira.emailEnv}`);
  const auth=c.jira.auth==='bearer'?`Bearer ${token}`:`Basic ${Buffer.from(`${email}:${token}`).toString('base64')}`;
  const response=await fetch(url,{headers:{Authorization:auth,Accept:'application/json'},signal:AbortSignal.timeout(30000),redirect:'error'});
  if(!response.ok) throw new Error(`Jira request failed: HTTP ${response.status}`);
  return response.json();
}
export async function issue(c,key) {
  ticketKey(key);
  const data=await jira(c,`issue/${key}`,{fields:'summary,description,comment,issuelinks,attachment,status,assignee,components,labels'});
  // Jira's embedded comments may be truncated; fetch every page explicitly.
  const comments=[]; let startAt=0;
  while(true) {
    const page=await jira(c,`issue/${key}/comment`,{startAt,maxResults:100});
    comments.push(...page.comments); startAt+=page.comments.length;
    if(startAt>=page.total || !page.comments.length) break;
  }
  return {key:data.key,url:`${c.jira.baseUrl.replace(/\/$/,'')}/browse/${key}`,fields:{...data.fields,comment:{comments}}};
}
export async function queue(c) {
  if(!c.jira.jql) throw new Error('Set jira.jql to explicitly select eligible stories');
  const keys=[]; let startAt=0,nextPageToken;
  for(let pages=0;pages<100;pages++) {
    const cloud=c.jira.apiVersion==='3';
    const data=await jira(c,cloud?'search/jql':'search',{jql:c.jira.jql,fields:'key',maxResults:100,...(cloud?(nextPageToken?{nextPageToken}:{}):{startAt})});
    keys.push(...data.issues.map(x=>ticketKey(x.key)));
    if(cloud){if(!data.nextPageToken) return keys;nextPageToken=data.nextPageToken;}
    else {startAt+=data.issues.length;if(startAt>=data.total || !data.issues.length)return keys;}
  }
  throw new Error('Jira queue exceeded 100 pages; narrow the JQL');
}
