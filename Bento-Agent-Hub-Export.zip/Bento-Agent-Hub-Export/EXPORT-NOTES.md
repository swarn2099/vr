# Bento Agent Hub export

This folder contains the Agent Hub source, Copilot agent definitions, VS Code extension and VSIX, configuration examples, documentation, tests, and dependency lockfile.

The original project remains unchanged. Dependencies (`node_modules`), runtime state/worktrees (`.bento`), Git history and local credentials/configuration are excluded.

Run `npm ci` in this folder to install dependencies, then open `Bento.code-workspace` in VS Code. The workspace points to this exported hub and the three sibling Bento repositories. See `README.md` for the remaining integration setup.
