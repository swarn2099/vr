import test from 'node:test';
import assert from 'node:assert/strict';
import {queue,issue} from '../src/jira.js';
const c={jira:{baseUrl:'https://jira.example',apiVersion:'3',auth:'bearer',tokenEnv:'BENTO_TEST_JIRA_TOKEN',jql:'assignee = currentUser()'}};
function mock(t,handler){const old=globalThis.fetch;process.env.BENTO_TEST_JIRA_TOKEN='test-only-token';globalThis.fetch=handler;t.after(()=>{globalThis.fetch=old;delete process.env.BENTO_TEST_JIRA_TOKEN;});}
test('Jira Cloud discovery follows tokens and preserves the filter',async t=>{const urls=[];mock(t,async url=>{urls.push(url);return {ok:true,json:async()=>urls.length===1?{issues:[{key:'TEST-1'}],nextPageToken:'next'}:{issues:[{key:'TEST-2'}]}};});assert.deepEqual(await queue(c),['TEST-1','TEST-2']);assert.equal(urls[1].searchParams.get('nextPageToken'),'next');assert.equal(urls[1].searchParams.get('jql'),c.jira.jql);});
test('Jira intake loads all comment pages',async t=>{let comments=0;mock(t,async url=>({ok:true,json:async()=>url.pathname.endsWith('/comment')?(++comments===1?{total:2,comments:[{body:'first'}]}:{total:2,comments:[{body:'second'}]}):{key:'TEST-1',fields:{summary:'Test'}}}));const result=await issue(c,'TEST-1');assert.equal(result.fields.comment.comments.length,2);assert.equal(comments,2);});
test('Jira authentication failures are not empty successful queues',async t=>{mock(t,async()=>({ok:false,status:401}));await assert.rejects(queue(c),/HTTP 401/);});
