import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { Store, ticketKey } from '../src/store.js';
import { Runner } from '../src/runner.js';
import { classifyChecks, makeWorktree, assertPublishable, fingerprint } from '../src/github.js';
import { command,redact } from '../src/process.js';
import { validateResult } from '../src/agent.js';
import { expandEnv } from '../src/config.js';
function temp(t){const p=fs.mkdtempSync(path.join(os.tmpdir(),'bento-test-'));t.after(()=>fs.rmSync(p,{recursive:true,force:true}));return p;}
function fixture(t,overrides={}){
 const dir=temp(t),c={root:dir,stateDir:dir,jira:{baseUrl:'https://jira.example'},repos:{webclient:{base:'dev',checks:[['test']],requiredChecks:['build']}},maxRepairAttempts:2,commandTimeoutMinutes:1,concurrency:2};
 const plan={summary:'Fix story',repos:['webclient'],acceptanceCriteria:['Expected behavior'],uiRequired:false,figmaUrls:[]};
 const counts={publish:0,agent:0};
 const services={fingerprint:async()=>'same',issue:async()=>({summary:'Issue'}),agent:async(c,s,phase)=>{counts.agent++;return {result:phase==='intake'?plan:{summary:'Done',verified:true,evidence:['test passed']}};},makeWorktree:async()=>({path:dir,branch:'feature/test-1-agent'}),command:async()=>({code:0,output:'ok'}),publish:async()=>{counts.publish++;return {number:1,sha:'head',url:'https://github.com/test/repo/pull/1'};},inspectCI:async()=>({state:'passed'}),failureLogs:async()=>'Compiler failed',queue:async()=>['TEST-1','TEST-1'],...overrides};
 return {runner:new Runner(c,services),counts,c};
}
test('ticket keys reject paths and command fragments',()=>{for(const bad of ['../x','abc-1','ABC-0','ABC-1; touch x','ABC-1/../../x'])assert.throws(()=>ticketKey(bad));assert.equal(ticketKey('BBSMPLAT-123'),'BBSMPLAT-123');});
test('state persists questions and answers across instances',t=>{const p=temp(t),a=new Store(p);const s=a.create('TEST-1');s.status='needs-input';s.question='Which brand?';a.save(s);const b=new Store(p);b.answer('TEST-1','US Bank');assert.equal(a.get('TEST-1').answers[0].answer,'US Bank');assert.equal(a.get('TEST-1').status,'queued');assert.throws(()=>b.answer('TEST-1','duplicate'));});
test('live run lock prevents another runner and is released',t=>{const s=new Store(temp(t));const release=s.lock('TEST-1');assert.throws(()=>s.lock('TEST-1'),/already running/);release();s.lock('TEST-1')();});
test('no checks, missing required checks, skipped required and pending never pass',()=>{const success={name:'build',status:'completed',conclusion:'success'};assert.equal(classifyChecks([],[]).state,'pending');assert.equal(classifyChecks([success],[],['mobile']).state,'pending');assert.equal(classifyChecks([{...success,conclusion:'skipped'}],[],['build']).state,'pending');assert.equal(classifyChecks([{...success,status:'in_progress'}],[],['build']).state,'pending');assert.equal(classifyChecks([success],[],['build']).state,'passed');});
test('failed optional checks also trigger repair',()=>{assert.equal(classifyChecks([{name:'lint',status:'completed',conclusion:'failure'}],[{context:'build',state:'success'}],['build']).state,'failed');});
test('end-to-end fixture reaches review-ready and reruns do not republish',async t=>{const {runner,counts}=fixture(t);const result=await runner.run('TEST-1');assert.equal(result.status,'ready');assert.equal(counts.publish,1);await runner.run('TEST-1');assert.equal(counts.publish,1);});
test('clarification resumes the same stage without losing previous work',async t=>{let question=true;const {runner,counts}=fixture(t,{agent:async(c,s,phase)=>{if(phase==='verify'&&question)return {question:'Which design?'};return {result:phase==='intake'?{summary:'Fix',repos:['webclient'],acceptanceCriteria:['Works'],uiRequired:true,figmaUrls:[]}:{summary:'done',verified:true,evidence:['screen']}};}});assert.equal((await runner.run('TEST-1')).status,'needs-input');assert.equal(counts.publish,0);runner.store.answer('TEST-1','Use linked design');question=false;assert.equal((await runner.run('TEST-1')).status,'ready');assert.equal(counts.publish,1);});
test('CI repair revalidates, reverifies and publishes a new revision',async t=>{let checks=0;const {runner,counts}=fixture(t,{inspectCI:async()=>({state:checks++===0?'failed':'passed'})});const result=await runner.run('TEST-1');assert.equal(result.status,'ready');assert.equal(result.attempts,1);assert.equal(counts.publish,2);assert.equal(result.validation[0].code,0);});
test('repair limit stops a failing workflow without publishing',async t=>{const {runner,counts}=fixture(t,{command:async()=>({code:1,output:'error'})});const result=await runner.run('TEST-1');assert.equal(result.status,'needs-input');assert.equal(result.attempts,2);assert.equal(counts.publish,0);});
test('pending CI is resumed by a later run',async t=>{let done=false;const {runner,counts}=fixture(t,{inspectCI:async()=>({state:done?'passed':'pending'})});assert.equal((await runner.run('TEST-1')).status,'waiting-ci');done=true;assert.equal((await runner.run('TEST-1')).status,'ready');assert.equal(counts.publish,1);});
test('no configured required checks stops before claiming green',async t=>{const {runner,c}=fixture(t);c.repos.webclient.requiredChecks=[];assert.equal((await runner.run('TEST-1')).status,'needs-input');});
test('paused stories do not run until resumed',async t=>{const {runner,counts}=fixture(t);runner.store.pause('TEST-1');assert.equal((await runner.run('TEST-1')).status,'paused');assert.equal(counts.agent,0);runner.store.unpause('TEST-1');assert.equal((await runner.run('TEST-1',{resume:true})).status,'ready');});
test('discovery failures still permit CI monitoring',async t=>{let done=false;const {runner}=fixture(t,{queue:async()=>{throw new Error('Jira down');},inspectCI:async()=>({state:done?'passed':'pending'})});await runner.run('TEST-1');done=true;const tick=await runner.tick();assert.equal(tick.discoveryError,'Jira down');assert.equal(runner.store.get('TEST-1').status,'ready');});
test('malformed agent results cannot satisfy validation',()=>{assert.throws(()=>validateResult('verify',{summary:'ok',verified:true,evidence:[]},{}));assert.throws(()=>validateResult('intake',{summary:'ok',repos:['unknown']},{repos:{}}));});
test('environment references fail closed and secrets are redacted',()=>{process.env.BENTO_TEST_TOKEN='secret-value-123';assert.equal(expandEnv('${env:BENTO_TEST_TOKEN}'),'secret-value-123');assert.equal(redact('token secret-value-123'),'token [REDACTED]');delete process.env.BENTO_TEST_TOKEN;assert.throws(()=>expandEnv('${env:BENTO_TEST_TOKEN}'));});
test('shell arguments remain literal and timeouts terminate children',async t=>{const p=temp(t);const r=await command([process.execPath,'-e','console.log(process.argv[1])','$(touch hacked)'],p);assert.equal(r.output.trim(),'$(touch hacked)');assert.equal(fs.existsSync(path.join(p,'hacked')),false);const timeout=await command([process.execPath,'-e','setInterval(()=>{},1000)'],p,{timeout:50,allowFailure:true});assert.equal(timeout.timedOut,true);});
test('worktrees start from the requested remote base and preserve original branch',async t=>{
 const dir=temp(t),remote=path.join(dir,'remote.git'),repo=path.join(dir,'repo');
 await command(['git','init','--bare',remote],dir);await command(['git','clone',remote,repo],dir);
 await command(['git','config','user.email','test@example.invalid'],repo);await command(['git','config','user.name','Test'],repo);
 fs.writeFileSync(path.join(repo,'a.txt'),'base');await command(['git','add','.'],repo);await command(['git','commit','-m','base'],repo);await command(['git','branch','-M','dev'],repo);await command(['git','push','origin','dev'],repo);await command(['git','checkout','-b','my-current-work'],repo);
 const c={stateDir:path.join(dir,'state'),repos:{webclient:{path:repo,base:'dev'}}};const w=await makeWorktree(c,{key:'TEST-1'},'webclient');assert.equal(fs.readFileSync(path.join(w.path,'a.txt'),'utf8'),'base');assert.equal((await command(['git','branch','--show-current'],repo)).output.trim(),'my-current-work');assert.deepEqual(await makeWorktree(c,{key:'TEST-1'},'webclient'),w);
});

test('publish rejects local credentials and added private keys',()=>{assert.throws(()=>assertPublishable(['.env.dev'],''));assert.throws(()=>assertPublishable(['src/config.ts'],'+const key="github_pat_12345678901234567890123456"'));assert.doesNotThrow(()=>assertPublishable(['.env.example','src/index.ts'],''));});
test('source changes during verification force a fresh validation pass',async t=>{let value=0,calls=0;const {runner}=fixture(t,{fingerprint:async()=>String(value),command:async()=>{calls++;return {code:0,output:'ok'};}});const original=runner.services.agent;runner.services.agent=async(c,s,stage)=>{const result=await original(c,s,stage);if(stage==='verify'&&value===0)value++;return result;};assert.equal((await runner.run('TEST-1')).status,'ready');assert.equal(calls,2);});

test('cancellation rejects the command and stops the child',async t=>{const dir=temp(t),controller=new AbortController();const pending=command([process.execPath,'-e','setInterval(()=>{},1000)'],dir,{signal:controller.signal});setTimeout(()=>controller.abort(),40);await assert.rejects(pending,/cancelled/);});
test('creation cannot bypass a live story lock',t=>{const store=new Store(temp(t));const release=store.lock('TEST-1');assert.throws(()=>store.create('TEST-1'),/already running/);release();assert.equal(store.create('TEST-1').status,'queued');});
