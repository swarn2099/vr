# Verified Regeneration Workstation Alpha V1

This bundle contains the generic `verified-regeneration` Python wheel and this installation guide. It contains no product source or prebuilt project knowledge.

## Install on another Mac or workstation

Python 3.9 or newer is required. From the directory where you unzip this bundle, run:

```bash
python3 -m venv .venv
source .venv/bin/activate
python3 -m pip install --no-index ./verified_regeneration-0.1.0-py3-none-any.whl
```

Then move to the root of the source estate you want VR to inspect:

```bash
cd /path/to/your/software-estate
vr init
vr status
vr ask "How does a known behavior work?"
vr task "Describe a small change to prepare"
```

VR stores all project-local discovery and resumable work in `.vr/` under that source estate. Initialization does not install the estate's dependencies, start its services, contact a model, or modify its product source.

## Interactive Copilot bridge

If `vr ask` needs semantic synthesis, open the generated `.vr/queries/QUERY-001/request.md` in VS Code, provide its bounded contents to Copilot Chat, save the structured JSON response, and import it with:

```bash
vr ask import QUERY-001 --import /path/to/resolver-response.json
```

For a task waiting on a resolver, open `.vr/tasks/TASK-001/resolver/request.md`, provide it to Copilot Chat, save the structured JSON response, and run:

```bash
vr resolve TASK-001 --import /path/to/resolver-response.json
vr task show TASK-001
```

To paste a response instead of importing a file, replace `--import ...` with `--stdin`, paste the JSON, and finish input with Ctrl-D on macOS/Linux or Ctrl-Z then Enter on Windows.

The included `MANIFEST.sha256` records the SHA-256 checksum of every other file in this bundle. To verify it on macOS:

```bash
shasum -a 256 -c MANIFEST.sha256
```
